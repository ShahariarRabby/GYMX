<HTML>
<HEAD>
    <TITLE>Oops! You bwoke it.</TITLE>
    <style>
        body{
            background-image: url(<?php echo e(asset('images/ss.png')); ?>);
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }
    </style>
<body >

</body>
</HTML>
