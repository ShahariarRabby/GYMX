<?php $__env->startSection('header'); ?>
    All Users
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
        


        
    
    <?php if(Session::has('create_user')): ?>
        <div class="alert alert-success" style="display: inline-block  " script="alert("asd");" role="alert">
            <strong>User Created Successfully !</strong>
        </div>
    <?php endif; ?>

    <?php if(Session::has('Update_user')): ?>
        <div class="alert alert-info" style="display: inline-block" role="alert">
            <strong>User Updated Successfully !</strong>
        </div>
    <?php endif; ?>

<?php if(Session::has('Delete_user')): ?>
    <div class="alert alert-danger" style="display: inline-block" role="alert">
        <strong>User Deleted</strong>
    </div>
  <?php endif; ?>

<table class="table table-hover table-responsive">
  <thead>
    <tr>
      <th>ID</th>
      <th>Photo</th>
      <th>Name</th>
      <th>Email</th>
      <th>Role</th>
      <th>Status</th>
      <th>Created</th>
      <th>Updated</th>

    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($user->id); ?></th>
      <th  ><img height="50px" width="50px" class="img-circle" src="<?php echo e(asset($user->photo ? ("images/".($user->photo->file)):($user->role_id==1?"images/2.png":"images/1.png"))); ?>" alt="<?php echo e($user->name); ?>"></th>
      <td><a href="<?php echo e(url('admin/users/' .$user->id . '/edit')); ?>"><?php echo e($user->name); ?></a></td>
        
      <td><?php echo e($user->email); ?></td>
      <td><?php echo e($user->role); ?></td>
      <td><?php echo e($user->is_active); ?></td>
      <td><?php echo e($user->	created_at->diffForHumans()); ?></td>
      <td><?php echo e($user->	updated_at->diffForHumans()); ?></td>
    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>












    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>