<?php $__env->startSection('header'); ?>
    Edit User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::model($user,['method'=>'PATCH','action'=>["AdminUsersController@update",$user->id],'files'=>true]); ?>


    <div class="col-sm-3 col-12" >
        <img src="<?php echo e(asset($user->photo ? ("images/".($user->photo->file)):($user->role_id==1?"images/2.png":"images/1.png"))); ?>" class="img-responsive img-rounded">
        
        <div style="overflow: hidden" class="form-group">
            <?php echo Form::label('photo_id','Edit Photo'); ?>

            <?php echo Form::file('photo_id',null,['class'=>'form-control']); ?>

        </div>
        

    </div>

    <div class="col-sm-9 col-12">

    <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form-group">
        <?php echo Form::label('Name','Name'); ?>

        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('email','Email'); ?>

        <?php echo Form::email('email',null,['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('password','Password'); ?>

        <?php echo Form::password('password',['class'=>'form-control','placeholder'=>"Password"]); ?>

    </div>

    
        
        
    

        <div class="form-group">
        <?php echo Form::label('role','Role'); ?>

            <?php echo Form::select('role',array('User'=>'User','Admin'=>'Admin'),'User',['class'=>'form-control']); ?>

        </div>

    <div class="form-group">
        <?php echo Form::label('is_active','Status'); ?>

        <?php echo Form::select('is_active',array(1=>'Active',0=>'Not Active'),null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group  col-sm-6">
        <?php echo Form::submit('Update User',['class'=>'btn btn-primary   col-sm-11']); ?>


    </div>



    <?php echo Form::Close(); ?>

    <?php echo Form::open(['method'=>'Delete','action'=>["AdminUsersController@destroy",$user->id]]); ?>



    <div class="form-group  col-sm-6">
        <?php echo Form::submit('Delete User',['class'=>'btn btn-danger col-sm-11']); ?>

    </div>
    <?php echo Form::Close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>